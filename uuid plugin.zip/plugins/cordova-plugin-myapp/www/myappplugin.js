/**
 * Created by nikul on 7/18/2017.
 */
'use strict';

var exec = require('cordova/exec');

var myAppPlugin = {};

myAppPlugin.getAndroidID = function(success, failure,options) {
  // fire
  exec(
    success,
    failure,
    'MyAppPlugin',
    'getAndroidID',
    [options]
  );
};
myAppPlugin.encrypt = function(success, failure,options) {
  // fire
  exec(
    success,
    failure,
    'MyAppPlugin',
    'encrypt',
    [options]
  );
};
myAppPlugin.decrypt = function(success, failure,options) {
  // fire
  exec(
    success,
    failure,
    'MyAppPlugin',
    'decrypt',
    [options]
  );
};



module.exports = myAppPlugin;
